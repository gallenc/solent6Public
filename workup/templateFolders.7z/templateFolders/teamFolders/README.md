# Team Folders

This folder contains separate team folders for gash projects, experiments etc 
which are not part of the overall group development.

Each team can choose how to use this or example among the team - but dont overwrite other peoples work :)