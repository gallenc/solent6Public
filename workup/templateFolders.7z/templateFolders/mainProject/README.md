# Traffic Management Project

This folder will be to share a common development project accross the teams.

Each team will work on this project in branches and merge their branches here using pull requests.