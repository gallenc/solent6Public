# Workup

Please do not put any of your code here.

This folder is used by Craig Gallen to prepare examples for the class. 

Anything in here may or may not work or be useful :)
